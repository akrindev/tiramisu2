<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ucapan_komen extends Model
{
    //
}
