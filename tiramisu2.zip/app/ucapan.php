<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ucapan extends Model
{
    //
}
