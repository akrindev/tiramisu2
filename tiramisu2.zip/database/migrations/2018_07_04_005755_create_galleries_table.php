<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGalleriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('galleries', function (Blueprint $table) {
            $table->charset = 'utf8mb4';
          	$table->collation = 'utf8mb4_unicode_ci';

            $table->increments('id');
          	$table->integer('user_id');
          	$table->text('body');
          	$table->string('gambar');
          	$table->integer('views')->default(0);
            $table->timestamps();
          	$table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('galleries');
    }
}